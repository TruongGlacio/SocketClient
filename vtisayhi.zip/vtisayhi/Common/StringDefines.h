#ifndef STRINGDEFINES_H
#define STRINGDEFINES_H
#include <QString>
#endif // STRINGDEFINES_H

