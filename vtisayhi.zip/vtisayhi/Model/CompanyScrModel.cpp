#include "CompanyScrModel.h"

CompanyScrModel::CompanyScrModel(QObject *parent) : QObject(parent)
{

}

QString CompanyScrModel::imgContent() const
{
    return m_imgContent;
}

void CompanyScrModel::setImgContent(QString imgContent)
{
    if (m_imgContent == imgContent)
        return;

    m_imgContent = imgContent;
    emit imgContentChanged(m_imgContent);
}
