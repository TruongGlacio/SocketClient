#ifndef MENUSCRMODEL_H
#define MENUSCRMODEL_H

#include <QObject>

class MenuScrModel : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString title READ title WRITE setTitle NOTIFY titleChanged)
    QString m_title;
public:
    explicit MenuScrModel(QObject *parent = nullptr);
    QString title() const;
public slots:
void setTitle(QString title);
signals:
void titleChanged(QString title);
};

#endif // MENUSCRMODEL_H

