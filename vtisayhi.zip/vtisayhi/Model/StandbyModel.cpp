#include "StandbyModel.h"
#include <QtDebug>
#include <QStandardPaths>
#include <VTILog.h>
#include <ConstDefines.h>

StandbyModel::StandbyModel(QObject *parent) : QObject (parent)
{
    isCustomerVisit = false;
}

StandbyModel::~StandbyModel()
{

}

QString StandbyModel::imageScr() const
{
    return mImageScr;
}

void StandbyModel::setImageScr(QString scr)
{
    mImageScr = scr;
    emit imageScrChanged(scr);
}

QString StandbyModel::videoScr() const
{
    return mVideoScr;
}

void StandbyModel::setVideoScr(QString scr)
{
    if (mVideoScr != scr){
        mVideoScr = scr;
        emit videoScrChanged(scr);
    }
}

QList<QString> StandbyModel::newsList()
{
    return mNewsList;
}

void StandbyModel::setNewsInfo(const QList<QString> &list)
{
    if(list.count() != 0)
    {
        mNewsList.clear();
        mNewsList = list;
        emit newsListChanged(list);
    }
}

bool StandbyModel::IsCustomerVisitUsToday()
{
    //TODO Check Date Time and return if
    // Cus visit us today.
    return false;
}
