#ifndef TECHSCRMODEL_H
#define TECHSCRMODEL_H

#include <QObject>
#include <QDateTime>
#include <QMap>
#include <QQmlApplicationEngine>
#include <QStack>

#include <Common/GlobalTypes.h>
#include <Common/ConstDefines.h>
#include <Common/GlobalTypes.h>

class TechScrModel : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString title READ title WRITE setTitle NOTIFY titleChanged)
    Q_PROPERTY(QString techInfoPath READ techInfoPath WRITE setTechInfoPath NOTIFY techInfoPathChanged)
    Q_PROPERTY(QString techDeConLeft READ techDeConLeft WRITE setTechDeConLeft NOTIFY techDeConLeftChanged)
    Q_PROPERTY(QString techDeConRight READ techDeConRight WRITE setTechDeConRight NOTIFY techDeConRightChanged)
    Q_PROPERTY(int curIndex READ curIndex WRITE setCurIndex NOTIFY curIndexChanged)
    QString m_title;

    QString m_techInfoPath;

    QString m_techDeConLeft;

    QString m_techDeConRight;
    QList <QString> mLinkOfContent1;
    QList <QString> mLinkOfContent2;
    QList <QString> mLinkOfContent3;
    QList <QString> mLinkOfContent4;

    int m_curIndex;

public:
    explicit TechScrModel(QObject *parent = nullptr);

    QString title() const;
    QString techInfoPath() const;
    QString techDeConLeft() const;
    QString techDeConRight() const;

    int RegisterObjectToQml(QQmlApplicationEngine * engine);
    void setLinkOfContent(ConfigTechnologies data);
    int curIndex() const;

signals:

void titleChanged(QString title);

void techInfoPathChanged(QString techInfoPath);

void techDeConLeftChanged(QString techDeConLeft);

void techDeConRightChanged(QString techDeConRight);

void curIndexChanged(int curIndex);

public slots:
void setTitle(QString title);
void setTechInfoPath(QString techInfoPath);
void setTechDeConLeft(QString techDeConLeft);
void setTechDeConRight(QString techDeConRight);
void setCurIndex(int curIndex);
};

#endif // TECHSCRMODEL_H
