#ifndef NEWSSCRMODEL_H
#define NEWSSCRMODEL_H

#include <QObject>

#include <QObject>
#include <QDateTime>
#include <QMap>
#include <QQmlApplicationEngine>
#include <QStack>

class NewsScrModel : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString leftContent READ leftContent WRITE setLeftContent NOTIFY leftContentChanged)
    Q_PROPERTY(QString rightContent READ rightContent WRITE setRightContent NOTIFY rightContentChanged)
    Q_PROPERTY(QString mainContent READ mainContent WRITE setMainContent NOTIFY mainContentChanged)
    Q_PROPERTY(int curIndex READ curIndex WRITE setCurIndex NOTIFY curIndexChanged)
private:
    QString m_leftContent;

    QString m_rightContent;

    QString m_mainContent;

    int m_curIndex;

    QList<QString> mPageContentList;
public:
explicit NewsScrModel(QObject *parent = nullptr);
int RegisterObjectToQml(QQmlApplicationEngine * engine);


QString leftContent() const;
QString rightContent() const;
QString mainContent() const;
void    SetPageContentList(const QList<QString>& list);
int curIndex() const;

public slots:

void setLeftContent(QString leftContent);
void setRightContent(QString rightContent);

void setMainContent(QString mainContent);

void setCurIndex(int curIndex);

signals:

void leftContentChanged(QString leftContent);
void rightContentChanged(QString rightContent);
void mainContentChanged(QString mainContent);
void curIndexChanged(int curIndex);
};

#endif // NEWSSCRMODEL_H
