#ifndef COMPANYSCRMODEL_H
#define COMPANYSCRMODEL_H

#include <QObject>

class CompanyScrModel : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString imgContent READ imgContent WRITE setImgContent NOTIFY imgContentChanged)
    QString m_imgContent;

public:
    explicit CompanyScrModel(QObject *parent = nullptr);

QString imgContent() const;

signals:

void imgContentChanged(QString imgContent);

public slots:
void setImgContent(QString imgContent);
};

#endif // COMPANYSCRMODEL_H
