#include "MenuScrModel.h"

MenuScrModel::MenuScrModel(QObject *parent) : QObject(parent)
{
    setTitle("Welcome Mr. Tien to VTI");
}

QString MenuScrModel::title() const
{
    return m_title;
}

void MenuScrModel::setTitle(QString title)
{
    if (m_title != title) {
        m_title = title;
        emit titleChanged(m_title);
    }
}
