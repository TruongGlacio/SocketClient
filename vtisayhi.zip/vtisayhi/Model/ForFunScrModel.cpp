#include "ForFunScrModel.h"

ForFunScrModel::ForFunScrModel(QObject *parent) : QObject(parent)
{

}

QString ForFunScrModel::imgContent() const
{
    return m_imgContent;
}

void ForFunScrModel::setImgContent(QString imgContent)
{
    if (m_imgContent == imgContent)
        return;

    m_imgContent = imgContent;
    emit imgContentChanged(m_imgContent);
}
