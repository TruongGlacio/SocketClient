#ifndef FORFUNSCRMODEL_H
#define FORFUNSCRMODEL_H

#include <QObject>

class ForFunScrModel : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString imgContent READ imgContent WRITE setImgContent NOTIFY imgContentChanged)
    QString m_imgContent;

public:
    explicit ForFunScrModel(QObject *parent = nullptr);

QString imgContent() const;

signals:

void imgContentChanged(QString imgContent);

public slots:
void setImgContent(QString imgContent);
};

#endif // FORFUNSCRMODEL_H
