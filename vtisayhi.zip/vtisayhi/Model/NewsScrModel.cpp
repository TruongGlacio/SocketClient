#include "NewsScrModel.h"

#include <QMetaObject>
#include <QQmlComponent>
#include <QQmlContext>
#include "Common/ConstDefines.h"
#include <QtDebug>
#include <QStandardPaths>
#include <VTILog.h>
#include <ConstDefines.h>

NewsScrModel::NewsScrModel(QObject *parent) : QObject(parent)
{
    setLeftContent("123");
    setMainContent("333");
    setRightContent("345");
    setCurIndex(0);
}

int NewsScrModel::RegisterObjectToQml(QQmlApplicationEngine * engine)
{
    engine->rootContext()->setContextProperty(OBJ_NEWSSCR_MODEL, this);
    return  1;
}


QString NewsScrModel::leftContent() const
{
    return m_leftContent;
}

void NewsScrModel::setLeftContent(QString leftContent)
{
    if (m_leftContent != leftContent) {
        m_leftContent = leftContent;
        emit leftContentChanged(m_leftContent);
    }
}

QString NewsScrModel::mainContent() const
{
    return m_mainContent;
}

void NewsScrModel::SetPageContentList(const QList<QString> &list)
{
    mPageContentList = list;
    setCurIndex(0);
}

void NewsScrModel::setMainContent(QString mainContent)
{
    if (m_mainContent != mainContent) {
        m_mainContent = mainContent;
        emit mainContentChanged(m_mainContent);
    }
}

QString NewsScrModel::rightContent() const
{
    return m_rightContent;
}

void NewsScrModel::setRightContent(QString rightContent)
{
    if (m_rightContent != rightContent) {
        m_rightContent = rightContent;
        emit rightContentChanged(m_rightContent);
    }
}

int NewsScrModel::curIndex() const
{
    return m_curIndex;
}

void NewsScrModel::setCurIndex(int curIndex)
{
    if (m_curIndex != curIndex && curIndex >= 0 && curIndex < mPageContentList.count())
    {
        m_curIndex = curIndex;

        if (mPageContentList.count() > 0)
        {
            if (m_curIndex == 0)
            {
                setLeftContent("");
                setMainContent(mPageContentList[0]);
                if (mPageContentList.count() > 1 )
                {
                    setRightContent(mPageContentList[1]);
                }
                else
                {
                    setRightContent("");
                }
            }
            else if (m_curIndex >= 1)
            {
                setLeftContent(mPageContentList[m_curIndex - 1]);
                setMainContent(mPageContentList[m_curIndex]);
                if (mPageContentList.count() > m_curIndex + 1 )
                {
                    setRightContent(mPageContentList[m_curIndex + 1]);
                }
                else
                {
                    setRightContent("");
                }
            }
            else
            {
                setLeftContent("");
                setMainContent("");
                setRightContent("");
            }
        }

        emit curIndexChanged(m_curIndex);
    }
}
