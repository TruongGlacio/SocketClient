#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H
#include <QObject>
#include <Common/GlobalTypes.h>
#include <Common/ConstDefines.h>
#include <Common/VTIUtility.h>
#include <QJsonObject>

class DatabaseManager: public QObject
{
    Q_OBJECT
public:
    explicit DatabaseManager(QObject *parent = nullptr);
    ~DatabaseManager();
    void Init(const QString &path);

    QList<QString> GetNewsInfo();
    QString GetStandByVideo();
    QString GetMenuVideo();
    QString GetCompanyStructureImagePath();
    ConfigTechnologies GetTechnologiesInfo();
    QList<CustomerInfo> GetCustomerInfo();
    QList<QString> GetOthersScreenInfo();

    void SetConfigPath(const QString& path);
    bool LoadConfig();
    bool WriteConfig();

    QString ConstructPathFile(QString path, QString dateTime, QString fileName);

private:
    bool mIsUpdateFromServer;
    ConfigData mDataConfig;
    QString mDataFolderPath;
    Config mConfigInfo;

    QString GetNewsPath();
    QString GetCompanyStructurePath();
    QString GetGuideLineVideoPath();
    QString GetStandbyDataPath();
    QString GetOtherInfoDataPath();
    QString GetTechInfoPath();
    QString GetConfigPath();


public slots:
    void onNewsInfoChanged(const QList<QString> &list);
    void onStandByVideoChanged(const QString &path);
    void onMenuVideoChanged(const QString &path);
    void onCompanyStructureImagePathChanged(const QString &path);
    void onTechnologiesInfoChanged(const ConfigTechnologies &info);
    void onCustomerInfoChanged(const QList<CustomerInfo> &info);
    void onOthersScreenInfoChanged(const QList<QString> &info);
    void onUpdateScr(int scr);
    void onUpdateFromServer();
    void onDownloadDataCompleted(VTIEnum::JsonDataType, QJsonObject obj);
    void onWriteConfigCompleted();
signals:
    void configChanged();
    void updateDataFromServer();
    void writeConfigCompleted();
    //void onDownloadNewsDataCompleted(VTIEnum::JsonDataType type, QJsonObject obj);
};

#endif // DATABASEMANAGER_H
