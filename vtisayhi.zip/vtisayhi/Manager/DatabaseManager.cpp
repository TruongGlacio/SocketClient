#include "DatabaseManager.h"
#include "VTIEnum.h"
#include "VTILog.h"
#include <QJsonArray>

DatabaseManager::DatabaseManager(QObject *parent): QObject (parent)
{
    mIsUpdateFromServer = false;
}

DatabaseManager::~DatabaseManager()
{

}

void DatabaseManager::Init(const QString &path)
{
    DEBUG << "DatabaseManager::Init";
    mDataFolderPath = path;
    //LoadConfig();

    //WILL_REMOVE_BEGIN
    QJsonArray arr;
    arr.append("1.jpg");
    arr.append("2.jpg");
    arr.append("3.jpg");
    arr.append("4.jpg");
    arr.append("5.jpg");
    arr.append("6.jpg");
    QJsonObject _newsJson;
    _newsJson ["data"] = arr;
    _newsJson ["createDate"] = QString("20181218");
    onDownloadDataCompleted(VTIEnum::JsonDataType::News, _newsJson);

    QJsonObject _standbyVideo;
    _standbyVideo ["name"] = QString("1.mp4");
    _standbyVideo ["createDate"] = QString("20181218");
    onDownloadDataCompleted(VTIEnum::JsonDataType::StandbyVideoInfo, _standbyVideo);
    //WILL_REMOVE_END
}

QList<QString> DatabaseManager::GetNewsInfo()
{
    return mConfigInfo.data.newsInfo;//mNewsInfo;
}

QString DatabaseManager::GetStandByVideo()
{
    return mConfigInfo.data.standbyVideoPath;//mStanbyVideoPath;
}

QString DatabaseManager::GetMenuVideo()
{
    return  mConfigInfo.data.menuVideoPath;//mMenuVideoPath;
}

QString DatabaseManager::GetCompanyStructureImagePath()
{
    return mConfigInfo.data.companyStructureImagePath;//mCompanyStructureImagePath;
}

ConfigTechnologies DatabaseManager::GetTechnologiesInfo()
{
    return mConfigInfo.data.technologies;//mTechnologies;
}

QList<CustomerInfo> DatabaseManager::GetCustomerInfo()
{
    return mConfigInfo.data.customerInfo;//mCustomer;
}

QList<QString> DatabaseManager::GetOthersScreenInfo()
{
    return mConfigInfo.data.othersInfo;//mOthersScreenInfo;
}

void DatabaseManager::SetConfigPath(const QString &path)
{
    mDataFolderPath = path;
}

bool DatabaseManager::LoadConfig()
{
    DEBUG << "DatabaseManager::LoadConfig";
    mConfigInfo = VTIUtility::ReadConfigDataJson(this->GetConfigPath());
    emit configChanged();
    return true;
}

bool DatabaseManager::WriteConfig()
{
    //TODO Write config json
    DEBUG << "DatabaseManager::WriteConfig";
    VTIUtility::WriteConfigDataJson(mConfigInfo, GetConfigPath());
    emit writeConfigCompleted();
    return true;
}

QString DatabaseManager::ConstructPathFile(QString path, QString dateTime, QString fileName)
{
    return "file:///" + path + dateTime + "/" + fileName;
}

QString DatabaseManager::GetNewsPath()
{
    return mDataFolderPath + PATH_NEWS_DATA;
}

QString DatabaseManager::GetCompanyStructurePath()
{
    return mDataFolderPath + PATH_COMPANY_STRUCTURE_DATA;
}

QString DatabaseManager::GetGuideLineVideoPath()
{
    return mDataFolderPath + PATH_GUIDELINE_VIDEO_DATA;
}

QString DatabaseManager::GetStandbyDataPath()
{
    return mDataFolderPath + PATH_STANDBY_DATA;
}

QString DatabaseManager::GetOtherInfoDataPath()
{
    return mDataFolderPath + PATH_STANDBY_DATA;
}

QString DatabaseManager::GetTechInfoPath()
{
    return mDataFolderPath + PATH_TECH_DATA;
}

QString DatabaseManager::GetConfigPath()
{
    return mDataFolderPath + PATH_CONFIG;
}

void DatabaseManager::onNewsInfoChanged(const QList<QString> &list)
{
    //mNewsInfo = list;
    mConfigInfo.data.newsInfo = list;
}
void DatabaseManager::onStandByVideoChanged(const QString &path)
{
    //if (QString::compare(mStanbyVideoPath, path, Qt::CaseSensitive) != 0)
    //{
    mConfigInfo.data.standbyVideoPath = path;
        //mStanbyVideoPath = path;
    //}
}

void DatabaseManager::onMenuVideoChanged(const QString &path)
{
//    if (QString::compare(mMenuVideoPath, path, Qt::CaseSensitive) != 0)
//    {
//        mMenuVideoPath = path;
//    }
    mConfigInfo.data.menuVideoPath = path;
}

void DatabaseManager::onCompanyStructureImagePathChanged(const QString &path)
{
//    if (QString::compare(mCompanyStructureImagePath, path, Qt::CaseSensitive) != 0)
//    {
//        mCompanyStructureImagePath = path;
//    }
    mConfigInfo.data.companyStructureImagePath = path;
}

void DatabaseManager::onTechnologiesInfoChanged(const ConfigTechnologies &info)
{
    mConfigInfo.data.technologies = info;
    //mTechnologies = info;
}

void DatabaseManager::onCustomerInfoChanged(const QList<CustomerInfo> &info)
{
    mConfigInfo.data.customerInfo = info;
}

void DatabaseManager::onOthersScreenInfoChanged(const QList<QString> &info)
{
    mConfigInfo.data.othersInfo = info;
}

void DatabaseManager::onDownloadDataCompleted(VTIEnum::JsonDataType type, QJsonObject jsonObj)
{
    DEBUG << "DatabaseManager::onDownloadDataCompleted";
    switch (type) {
    case VTIEnum::JsonDataType::News:
    {
        auto obj = VTIUtility::ReadNewsDataJson(jsonObj);//(obj);
        QString dateTimeStr = obj.createDate;
        QList<QString> tempList;
        for (int i = 0; i < obj.data.count(); i++)
        {
            tempList.append(ConstructPathFile(GetNewsPath(), dateTimeStr, obj.data.at(i)));
        }
        mConfigInfo.data.newsInfo = tempList;
        break;
    }
    case VTIEnum::JsonDataType::CustomerInfo:
    {
        auto obj = VTIUtility::ReadCustomerDataJson(jsonObj);//(obj);
        QString dateTimeStr = obj.createDate;
        mConfigInfo.data.customerInfo.clear();
        for (int i = 0; i < obj.info.count(); i++)
        {
             mConfigInfo.data.customerInfo.append(obj.info.at(i));
        }
        break;
    }
    case VTIEnum::JsonDataType::TechInfo:
    {
        auto obj = VTIUtility::ReadTechInfoDataJson(jsonObj);//(obj);
        QString dateTimeStr = obj.createDate;
        QList<QString> tempList;
        //Set main image path
        mConfigInfo.data.technologies.mainImagePath = ConstructPathFile(GetTechInfoPath(),dateTimeStr, obj.mainImagePath);

        //Set IOT path
        for (int i = 0; i < obj.iOTInfo.count(); i++)
        {
            tempList.append(ConstructPathFile(GetTechInfoPath(), dateTimeStr, obj.iOTInfo.at(i)));
        }
        mConfigInfo.data.technologies.iOTInfo = tempList;

        //Set AI path
        tempList.clear();
        for (int i = 0; i < obj.aIInfo.count(); i++)
        {
            tempList.append(ConstructPathFile(GetTechInfoPath(), dateTimeStr, obj.aIInfo.at(i)));
        }
        mConfigInfo.data.technologies.aIInfo = tempList;

        //Set cloudInfo path
        tempList.clear();
        for (int i = 0; i < obj.cloudInfo.count(); i++)
        {
            tempList.append(ConstructPathFile(GetTechInfoPath(), dateTimeStr, obj.cloudInfo.at(i)));
        }
        mConfigInfo.data.technologies.cloudInfo = tempList;

        //Set embeddedInfo path
        tempList.clear();
        for (int i = 0; i < obj.embeddedInfo.count(); i++)
        {
            tempList.append(ConstructPathFile(GetTechInfoPath(), dateTimeStr, obj.embeddedInfo.at(i)));
        }
        mConfigInfo.data.technologies.embeddedInfo = tempList;

        break;
    }
    case VTIEnum::JsonDataType::CompanyStructureInfo:
    {
        auto obj = VTIUtility::ReadCompanyDataJson(jsonObj);//(obj);
        QString dateTimeStr = obj.createDate;
        mConfigInfo.data.companyStructureImagePath = ConstructPathFile(GetCompanyStructurePath(), dateTimeStr, obj.name);
        break;
    }
    case VTIEnum::JsonDataType::StandbyVideoInfo:
    {
        auto obj = VTIUtility::ReadStandbyVideoDataJson(jsonObj);
        QString dateTimeStr = obj.createDate;
        mConfigInfo.data.standbyVideoPath = ConstructPathFile(GetStandbyDataPath(), dateTimeStr, obj.name);
        break;
    }
    case VTIEnum::JsonDataType::GuiLineVideoInfo:
    {
        auto obj = VTIUtility::ReadGuilineVideoDataJson(jsonObj);
        QString dateTimeStr = obj.creatdate;
        mConfigInfo.data.menuVideoPath = ConstructPathFile(GetGuideLineVideoPath(), dateTimeStr, obj.name);
        break;
    }
    case VTIEnum::JsonDataType::OtherInfo:
    {
        auto obj = VTIUtility::ReadOtherInfoJsonJson(jsonObj);//(obj);
        QString dateTimeStr = obj.createDate;
        QList<QString> tempList;
        for (int i = 0; i < obj.data.count(); i++)
        {
            tempList.append(ConstructPathFile(GetOtherInfoDataPath(), dateTimeStr, obj.data.at(i)));
        }
        mConfigInfo.data.othersInfo = tempList;
        break;
    }
    default:break;
    }

    WriteConfig();
}

void DatabaseManager::onWriteConfigCompleted()
{
    DEBUG << "DatabaseManager::onWriteConfigCompleted";
    LoadConfig();
}

void DatabaseManager::onUpdateScr(int scr)
{
    DEBUG << "DatabaseManager::onUpdateScr " << QString::number(scr);
    if (scr == VTIEnum::ScreenStandby && mIsUpdateFromServer)
    {
        updateDataFromServer();
        mIsUpdateFromServer = false;
    }
}

void DatabaseManager::onUpdateFromServer()
{
    mIsUpdateFromServer = true;
}
