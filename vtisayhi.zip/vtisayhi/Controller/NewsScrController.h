#ifndef NEWSSCRCONTROLLER_H
#define NEWSSCRCONTROLLER_H
#include <QObject>
#include "BaseController.h"
#include <qqmlapplicationengine.h>

class AppEngine;
class NewsScrModel;

class NewsScrController : public BaseController
{
public:
    NewsScrController(AppEngine* engine);
    ~NewsScrController();

    int RegisterObjectToQml(QQmlApplicationEngine * engine);
    bool LoadData() override;
    bool Init() override;

private:
    AppEngine *mAppEngine = nullptr;
    NewsScrModel *mNewsScrModel = nullptr;
};

#endif // NEWSSCRCONTROLLER_H
