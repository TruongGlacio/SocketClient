#include "MenuController.h"
#include "NewsScrModel.h"
#include "AppEngine.h"
#include <QQmlContext>
#include <Common/ConstDefines.h>
MenuController::MenuController(AppEngine *engine)
{
    mAppEngine = engine;
    mMenuScrModel = new MenuScrModel();
}

MenuController::~MenuController()
{
//    if (mNewsScrModel != nullptr)
//    {
//        delete mNewsScrModel;
//        mNewsScrModel = nullptr;
//    }
}

int MenuController::RegisterObjectToQml(QQmlApplicationEngine *engine)
{
    engine->rootContext()->setContextProperty(OBJ_MENU_CONTROLLER, this);
    engine->rootContext()->setContextProperty(OBJ_MENU_MODEL, mMenuScrModel);
    return 1;
}

bool MenuController::LoadData()
{

    //Implement DataLoade
    return true;
}

bool MenuController::Init()
{
    return true;// BaseController::Init();
}
