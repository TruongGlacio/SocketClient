#ifndef TECHSCRCONTROLLER_H
#define TECHSCRCONTROLLER_H
#include <QObject>
#include "BaseController.h"
#include <qqmlapplicationengine.h>
class AppEngine;
class TechScrModel;

class TechScrController : public BaseController
{
public:
    TechScrController(AppEngine* engine);
    ~TechScrController();

    int RegisterObjectToQml(QQmlApplicationEngine * engine);
    bool LoadData() override;
    bool Init() override;

private:
    AppEngine *mAppEngine = nullptr;
    TechScrModel *mTechScrModel = nullptr;


    // BaseController interface
};

#endif // TECHSCRCONTROLLER_H
