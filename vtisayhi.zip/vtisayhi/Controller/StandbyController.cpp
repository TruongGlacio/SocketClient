#include "StandbyController.h"
#include "../Common/Log/VTILog.h"
#include <QCoreApplication>
#include <QDir>
#include <QStandardPaths>
#include <QQmlContext>
#include "ConstDefines.h"
#include <DatabaseManager.h>
StandbyController::StandbyController(AppEngine *engine)
{
    QString homeLocation = QStandardPaths::locate(QStandardPaths::HomeLocation, QString(), QStandardPaths::LocateDirectory);
    DEBUG <<QStandardPaths::writableLocation(QStandardPaths::ApplicationsLocation) + PATH_VTISAYHI;
    DEBUG << QCoreApplication::applicationDirPath();
    DEBUG << SOURCE_PATH;
    mStandbyModel = new StandbyModel();
    mAppEngine = engine;
}

StandbyController::~StandbyController()
{
    if (mStandbyModel != nullptr)
    {
        delete mStandbyModel;
        mStandbyModel = nullptr;
    }
}

int StandbyController::RegisterObjectToQml(QQmlApplicationEngine *engine)
{
    engine->rootContext()->setContextProperty(OBJ_SCREEN_STANDBY_CONTROLLER, this);
    engine->rootContext()->setContextProperty(OBJ_SCREEN_STANDBY_MODEL, mStandbyModel);
    return 1;
}

void StandbyController::OnRequestShowScreen()
{
    mAppEngine->GetScreenManager()->reqGoTo(VTIEnum::ScreenID::ScreenStandby);
}

bool StandbyController::LoadData()
{
    DEBUG << "StandbyController::LoadData";
    //Implement DataLoade
    mStandbyModel->setNewsInfo(mAppEngine->GetDatabaseManager()->GetNewsInfo());
    mStandbyModel->setVideoScr(mAppEngine->GetDatabaseManager()->GetStandByVideo());
    return true;
}

bool StandbyController::Init()
{
    return true;//BaseController::Init();
}
