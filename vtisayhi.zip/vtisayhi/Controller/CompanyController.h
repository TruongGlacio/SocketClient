#ifndef COMPANYCONTROLLER_H
#define COMPANYCONTROLLER_H
#include <QObject>
#include "BaseController.h"
#include "Model/CompanyScrModel.h"
#include <qqmlapplicationengine.h>

class AppEngine;
class MenuScrModel;

class CompanyController : public BaseController
{
public:
    CompanyController(AppEngine* engine);
    ~CompanyController();

    int RegisterObjectToQml(QQmlApplicationEngine * engine);
    bool LoadData() override;
    bool Init() override;

private:
    AppEngine *mAppEngine = nullptr;
    CompanyScrModel *mCompanyScrModel = nullptr;
};

#endif // COMPANYCONTROLLER_H
