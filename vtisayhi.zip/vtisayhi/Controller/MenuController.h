#ifndef MENUCONTROLLER_H
#define MENUCONTROLLER_H
#include <QObject>
#include "BaseController.h"
#include "Model/MenuScrModel.h"
#include <qqmlapplicationengine.h>

class AppEngine;
class MenuScrModel;

class MenuController : public BaseController
{
public:
    MenuController(AppEngine* engine);
    ~MenuController();

    int RegisterObjectToQml(QQmlApplicationEngine * engine);
    bool LoadData() override;
    bool Init() override;

private:
    AppEngine *mAppEngine = nullptr;
    MenuScrModel *mMenuScrModel = nullptr;
};

#endif // MENUCONTROLLER_H
