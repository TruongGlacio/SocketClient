#include "ForfunController.h"
#include "NewsScrModel.h"
#include "AppEngine.h"
#include <QQmlContext>
#include "VTILog.h"
#include <Common/ConstDefines.h>

ForfunController::ForfunController(AppEngine* engine)
{
    mAppEngine = engine;
    mForFunScrModel = new ForFunScrModel();
}

ForfunController::~ForfunController()
{
//    if (mNewsScrModel != nullptr)
//    {
//        delete mNewsScrModel;
//        mNewsScrModel = nullptr;
//    }
}

int ForfunController::RegisterObjectToQml(QQmlApplicationEngine *engine)
{
    engine->rootContext()->setContextProperty(OBJ_FORFUN_CONTROLLER, this);
    engine->rootContext()->setContextProperty(OBJ_FORFUN_MODEL, mForFunScrModel);
    return 1;
}

bool ForfunController::LoadData()
{
    //Implement DataLoade
    DEBUG << "mAppEngine->GetDatabaseManager()->GetCompanyStructureImagePath()" << mAppEngine->GetDatabaseManager()->GetCompanyStructureImagePath();
    mForFunScrModel->setImgContent(mAppEngine->GetDatabaseManager()->GetCompanyStructureImagePath());  //SetPageContentList(mAppEngine->GetDatabaseManager()->GetNewsInfo());
    return true;
}

bool ForfunController::Init()
{
    return true;// BaseController::Init();
}
