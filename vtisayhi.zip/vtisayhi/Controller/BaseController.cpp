#include "BaseController.h"

BaseController::BaseController()
{

}

BaseController::~BaseController()
{

}

//bool BaseController::Init()
//{
//   //LoadData();
//}

void BaseController::OnDataChanged()
{
    LoadData();
}
