#ifndef FORFUNCONTROLLER_H
#define FORFUNCONTROLLER_H
#include <QObject>
#include "BaseController.h"
#include "Model/ForFunScrModel.h"
#include <qqmlapplicationengine.h>

class AppEngine;
class MenuScrModel;

class ForfunController : public BaseController
{
public:
    ForfunController(AppEngine* engine);
    ~ForfunController();

    int RegisterObjectToQml(QQmlApplicationEngine * engine);
    bool LoadData() override;
    bool Init() override;

private:
    AppEngine *mAppEngine = nullptr;
    ForFunScrModel *mForFunScrModel = nullptr;
};

#endif // FORFUNCONTROLLER_H
