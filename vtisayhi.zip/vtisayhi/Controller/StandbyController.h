#ifndef STANDBYCONTROLLER_H
#define STANDBYCONTROLLER_H
#include <QObject>
#include <qguiapplication.h>
#include <qqmlapplicationengine.h>
#include "StandbyModel.h"
#include "AppEngine.h"
#include "BaseController.h"

class StandbyController : public BaseController
{
public:
    StandbyController(AppEngine *engine = nullptr);
    ~StandbyController();

    int RegisterObjectToQml(QQmlApplicationEngine * engine);
    bool LoadData() override;
    bool Init() override;
private:
    StandbyModel *mStandbyModel;
    AppEngine *mAppEngine;
    QString temp;
signals:

public slots:
    void OnRequestShowScreen();
    bool OnNewData();

};

#endif // STANDBYCONTROLLER_H
