#ifndef STARTUPSCRCONTROLLER_H
#define STARTUPSCRCONTROLLER_H
#include <QObject>
#include "BaseController.h"
#include <qqmlapplicationengine.h>

class AppEngine;
class StartUpScrModel;
class StartUpScrController : public BaseController
{
public:
    StartUpScrController(AppEngine* engine);
    ~StartUpScrController();

    int RegisterObjectToQml(QQmlApplicationEngine * engine);
    bool LoadData() override;
    bool Init() override;

private:
    AppEngine *mAppEngine = nullptr;
    StartUpScrModel *mStartUpScrModel = nullptr;
};

#endif // STARTUPSCRCONTROLLER_H
