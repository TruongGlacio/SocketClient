#include "CompanyController.h"
#include "NewsScrModel.h"
#include "AppEngine.h"
#include <QQmlContext>
#include "VTILog.h"
#include <Common/ConstDefines.h>

CompanyController::CompanyController(AppEngine* engine)
{
    mAppEngine = engine;
    mCompanyScrModel = new CompanyScrModel();
}

CompanyController::~CompanyController()
{
//    if (mNewsScrModel != nullptr)
//    {
//        delete mNewsScrModel;
//        mNewsScrModel = nullptr;
//    }
}

int CompanyController::RegisterObjectToQml(QQmlApplicationEngine *engine)
{
    engine->rootContext()->setContextProperty(OBJ_COMPANY_CONTROLLER, this);
    engine->rootContext()->setContextProperty(OBJ_COMPANY_MODEL, mCompanyScrModel);
    return 1;
}

bool CompanyController::LoadData()
{
    //Implement DataLoade
    DEBUG << "mAppEngine->GetDatabaseManager()->GetCompanyStructureImagePath()" << mAppEngine->GetDatabaseManager()->GetCompanyStructureImagePath();
    mCompanyScrModel->setImgContent(mAppEngine->GetDatabaseManager()->GetCompanyStructureImagePath());  //SetPageContentList(mAppEngine->GetDatabaseManager()->GetNewsInfo());
    return true;
}

bool CompanyController::Init()
{
    return true;// BaseController::Init();
}
