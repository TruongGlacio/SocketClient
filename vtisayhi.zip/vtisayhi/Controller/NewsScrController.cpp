#include "NewsScrController.h"
#include "NewsScrModel.h"
#include "AppEngine.h"
#include <QQmlContext>
#include <Common/ConstDefines.h>
#include "VTILog.h"
NewsScrController::NewsScrController(AppEngine *engine)
{
    mAppEngine = engine;
    mNewsScrModel = new NewsScrModel();
}

NewsScrController::~NewsScrController()
{
    if (mNewsScrModel != nullptr)
    {
        delete mNewsScrModel;
        mNewsScrModel = nullptr;
    }
}

int NewsScrController::RegisterObjectToQml(QQmlApplicationEngine *engine)
{
    engine->rootContext()->setContextProperty(OBJ_NEWSSCR_CONTROLLER, this);
    engine->rootContext()->setContextProperty(OBJ_NEWSSCR_MODEL, mNewsScrModel);
    return 1;
}

bool NewsScrController::LoadData()
{
    //Implement DataLoade
    DEBUG << "mAppEngine->GetDatabaseManager()->GetNewsInfo()" << QString::number(mAppEngine->GetDatabaseManager()->GetNewsInfo().count());
    mNewsScrModel->SetPageContentList(mAppEngine->GetDatabaseManager()->GetNewsInfo());
    return true;
}

bool NewsScrController::Init()
{
    return true;
}
