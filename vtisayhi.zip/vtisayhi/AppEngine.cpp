#include "AppEngine.h"

#include <Common/VTIEnum.h>
#include <Controller/StandbyController.h>
#include <QDir>
#include <QStandardPaths>
#include <VTILog.h>
#include <ConstDefines.h>
#include "VTIUtility.h"
#include <PeopleDetectManager.h>
#include <MouseController.h>
#include <Controller/TechScrController.h>
#include <Controller/NewsScrController.h>
#include <Controller/StartUpScrController.h>

QGuiApplication *AppEngine::mApp = nullptr;
QQmlApplicationEngine *AppEngine::mEngine = nullptr;
AppEngine::AppEngine(QGuiApplication *app, QQmlApplicationEngine *engine, QObject *parent) :
    QObject(parent)
{
    mApp = app;
    mEngine = engine;

}

int AppEngine::Exec()
{
    return  mApp->exec();
}

QQmlApplicationEngine *AppEngine::GetEngine()
{
    return  mEngine;
}

QString AppEngine::GetDataPath()
{
    return QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + PATH_VTISAYHI;
}

DatabaseManager *AppEngine::GetDatabaseManager()
{
    return mDatabaseManager;
}

ScreenManager *AppEngine::GetScreenManager()
{
    return mScreenManager;
}

bool AppEngine::ConnectSignalsSlots()
{
    DEBUG<<"AppEngine::ConnectSignalsSlots";
    connect(mDatabaseManager        , &DatabaseManager::configChanged   , mStandByController    , &StandbyController::OnDataChanged);
    connect(mDatabaseManager        , &DatabaseManager::configChanged   , mTechScreenController , &TechScrController::OnDataChanged);
    connect(mDatabaseManager        , &DatabaseManager::configChanged   , mNewsScrController    , &NewsScrController::OnDataChanged);
    connect(mDatabaseManager        , &DatabaseManager::configChanged   , mStartUpScrController , &StartUpScrController::OnDataChanged);
    connect(mDatabaseManager        , &DatabaseManager::configChanged   , mMenuController       , &StartUpScrController::OnDataChanged);
    connect(mDatabaseManager        , &DatabaseManager::configChanged   , mCompanyController    , &CompanyController::OnDataChanged);
    connect(mDatabaseManager        , &DatabaseManager::configChanged   , mForfunController     , &ForfunController::OnDataChanged);
    connect(mScreenManager          , &ScreenManager::screenChanged     , mDatabaseManager      , &DatabaseManager::onUpdateScr);
    connect(mPeopleDetectManager    , &PeopleDetectManager::DetectPeople, this                  , &AppEngine::OnDetectPeople);
	connect(mDatabaseManager, &DatabaseManager::writeConfigCompleted, mDatabaseManager, &DatabaseManager::onWriteConfigCompleted);
    //TODO Connect WebClient dataChanged signal with Database Manager slots.

    return true;
}

bool AppEngine::DisConnectSignalsSlots()
{
    DEBUG<<"AppEngine::DisConnectSignalsSlots";
    disconnect(mDatabaseManager         , &DatabaseManager::configChanged   , mStandByController    , &StandbyController::OnDataChanged);
    disconnect(mDatabaseManager         , &DatabaseManager::configChanged   , mTechScreenController , &TechScrController::OnDataChanged);
    disconnect(mDatabaseManager         , &DatabaseManager::configChanged   , mNewsScrController    , &NewsScrController::OnDataChanged);
    disconnect(mDatabaseManager         , &DatabaseManager::configChanged   , mStartUpScrController , &StartUpScrController::OnDataChanged);
    disconnect(mDatabaseManager         , &DatabaseManager::configChanged   , mMenuController       , &StartUpScrController::OnDataChanged);
    disconnect(mDatabaseManager         , &DatabaseManager::configChanged   , mCompanyController    , &CompanyController::OnDataChanged);
    disconnect(mDatabaseManager         , &DatabaseManager::configChanged   , mForfunController     , &ForfunController::OnDataChanged);
    disconnect(mScreenManager           , &ScreenManager::screenChanged     , mDatabaseManager      , &DatabaseManager::onUpdateScr);
    disconnect(mPeopleDetectManager     , &PeopleDetectManager::DetectPeople, this                  , &AppEngine::OnDetectPeople);
	disconnect(mDatabaseManager, &DatabaseManager::writeConfigCompleted, mDatabaseManager, &DatabaseManager::onWriteConfigCompleted);
    //TODO DisConnect WebClient dataChanged signal with Database Manager slots.
    return true;
}

bool AppEngine::LoadConfig()
{
    if (mDatabaseManager)
    {
        mDatabaseManager->LoadConfig();
    }
    return true;
}

int AppEngine::LoadMainQml()
{
    if(!mApp || !mEngine)
        return  -1;
    mEngine->load(QUrl(QStringLiteral("qrc:/Qml/main.qml")));
    if (mEngine->rootObjects().isEmpty())
        return -1;
    mScreenManager->reqGoTo(1);
    return  Exec();
}

AppEngine::~AppEngine()
{
    this->DisConnectSignalsSlots();

    if(!mApp)
    {
        delete mApp;
        mApp = nullptr;
    }

    if(!mEngine)
    {
        delete  mEngine;
        mEngine = nullptr;
    }

    if(!mScreenManager)
    {
        delete  mScreenManager;
        mScreenManager = nullptr;
    }

    if (!mStandByController)
    {
        delete mStandByController;
        mStandByController = nullptr;
    }

    if (!mTechScreenController)
    {
        delete mTechScreenController;
        mTechScreenController = nullptr;
    }

    if (!mNewsScrController)
    {
        delete mNewsScrController;
        mNewsScrController = nullptr;
    }

    if (!mStartUpScrController)
    {
        delete mStartUpScrController;
        mStartUpScrController = nullptr;
    }

    if (!mMenuController)
    {
        delete mMenuController;
        mMenuController = nullptr;
    }

    if (!mDatabaseManager)
    {
        delete  mDatabaseManager;
        mDatabaseManager = nullptr;
    }

    if (!mCompanyController)
    {
        delete  mCompanyController;
        mCompanyController = nullptr;
    }

    if (!mForfunController)
    {
        delete  mForfunController;
        mForfunController = nullptr;
    }

    if (!mCheckDetectPeople)
    {

    }
}

int AppEngine::CreateObjects()
{
    mScreenManager = new ScreenManager();
    mStandByController = new StandbyController(this);
    mPeopleDetectManager = new PeopleDetectManager();
    mTechScreenController = new  TechScrController(this);
    mNewsScrController= new NewsScrController(this);
    mStartUpScrController = new StartUpScrController(this);
    mMenuController = new MenuController(this);    
    mCompanyController = new CompanyController(this);
    mForfunController = new ForfunController(this);
    mDatabaseManager = new DatabaseManager();

    mCheckDetectPeople = new QTimer(this);
    connect(mCheckDetectPeople, SIGNAL(timeout()), this, SLOT(OnCheckPeople()));
    mCheckDetectPeople->setInterval(CONFIG_TIMEOUT_DETECT_PEOPLE);
    mIsHavingPeople = false;
    return 1;
}

int AppEngine::InitObject()
{
    InitFolderPath();
    VTIEnum::declareQML();
    mScreenManager->Init();
    mPeopleDetectManager->SetUrl(DEFAULT_ADDRESS_WEBSERVER);
    mPeopleDetectManager->OpenConnection();
    mDatabaseManager->Init(GetDataPath());
    mStandByController->Init();
    mTechScreenController->Init();
    mNewsScrController->Init();
    mStartUpScrController->Init();
    mMenuController->Init();
    mCompanyController->Init();
    mForfunController->Init();
    return 1;
}

int AppEngine::InitFolderPath()
{
    QString vtiPath = GetDataPath();
    if(!QDir(vtiPath).exists())
    {
        QString source = SOURCE_PATH;
        VTIUtility::CopyRecursively(source + "/DataSample/VTISayHi/", vtiPath);
    }
    return  1;
}
int AppEngine::RegisterObjectToQml()
{
    mScreenManager->RegisterObjectToQml(mEngine);
    mStandByController->RegisterObjectToQml(mEngine);
    mTechScreenController->RegisterObjectToQml(mEngine);
    mNewsScrController->RegisterObjectToQml(mEngine);
    mStartUpScrController->RegisterObjectToQml(mEngine);
    mMenuController->RegisterObjectToQml(mEngine);
    mCompanyController->RegisterObjectToQml(mEngine);
    mForfunController->RegisterObjectToQml(mEngine);
    return  1;
}

void AppEngine::OnDetectPeople(bool isHavePeople)
{
    if (mIsHavingPeople != isHavePeople)
    {
        DEBUG << "OnDetectPeople " << isHavePeople << " , getCurrentScreen = " << QString::number(mScreenManager->getCurrentScreen());
        mIsHavingPeople = isHavePeople;
        if (!mCheckDetectPeople->isActive())
        {
            DEBUG << "mCheckDetectPeople->start()";
            mCheckDetectPeople->start();
        }
    }
}

void AppEngine::OnCheckPeople()
{
    DEBUG << "OnCheckPeople " << mIsHavingPeople << " , getCurrentScreen = " << QString::number(mScreenManager->getCurrentScreen());
    mCheckDetectPeople->stop();
    if (mIsHavingPeople && mScreenManager->getCurrentScreen() == VTIEnum::ScreenStandby)
    {
        mScreenManager->reqGoTo(VTIEnum::ScreenMenu);
    }
    else if (mScreenManager->getCurrentScreen() != VTIEnum::ScreenStandby)
    {
        mScreenManager->reqGoTo(VTIEnum::ScreenStandby);
    }
}
